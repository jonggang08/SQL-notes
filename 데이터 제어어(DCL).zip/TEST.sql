USE PRACTICE;

SELECT *
  FROM 회원테이블;
  
DELETE 
  FROM 회원테이블;